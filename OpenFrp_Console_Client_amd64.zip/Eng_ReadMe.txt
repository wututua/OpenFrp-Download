Thank you for using our Frp service! 
If you are using it for the first time, please generate a configuration file at the OpenFrp website and fill it in the frp.ini file. 
If you need anything else, 
Please ask our customer support : D